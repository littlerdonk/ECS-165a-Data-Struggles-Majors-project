# StruggleDB
Full M1 implimentation done by group Data Struggles Majors

Sage Dillemuth: Team lead, Tester completed about 40% total: Table.py and Page.py and bug test around 

Iris Yuan: Developer, completed about 15% total: Query.py

Alvin Guo: Developer, completed about 15% total: Index.py

Naomi Cohen: system architect, scheduling team meetings, completed about 15% total: Query.py

Nicholas Pinero: Developer, completed about 15% total: Table.py and Page.py


MileStone 2 Contributions:

Sage Dillemuth:

Iris Yuan: Developer, completed about 15% total: Bufferpool.py, Page.py

Alvin Guo: Developer, completed about 15%: Index.py, Query.py

Naomi Cohen: system architect, scheduling team meetings, completed about 15% total: db.py

Nicholas Pinero: Developer, completed about 15% total: Bufferpool.py
