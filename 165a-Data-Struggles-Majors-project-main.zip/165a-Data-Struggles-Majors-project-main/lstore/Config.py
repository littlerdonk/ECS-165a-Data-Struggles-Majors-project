# L store config global variable storage file 


#written by Sage for use in page.py 
PAGE_SIZE = 4096 #
RECORD_SIZE = 8
#Alvin wrote this to make it easier to find primary column
META_DATA_COLUMN_SIZE = 5
